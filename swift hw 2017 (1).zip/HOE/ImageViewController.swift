//
//  ImageViewController.swift
//  HOE
//
//  Created by Merlin Zhao on 11/19/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {

    
    @IBOutlet weak var capturedImage: UIImageView!
    
    @IBAction func cancelImage(_ sender: Any) {
    }
    
    @IBAction func goodImage(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //load image
        let picFood = UserDefaults.standard.object(forKey: "foodImage")
        capturedImage.image = UIImage(data: picFood as! Data)
        
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
