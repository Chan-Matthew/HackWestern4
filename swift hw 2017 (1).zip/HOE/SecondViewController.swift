//
//  SecondViewController.swift
//  HOE
//
//  Created by Merlin Zhao on 11/18/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
import AVKit

//added
import Firebase
import FirebaseDatabase
import FirebaseAnalytics
import Moya
import SwiftyJSON
//added

class SecondViewController: UIViewController,UINavigationControllerDelegate,UIImagePickerControllerDelegate,AVCaptureVideoDataOutputSampleBufferDelegate {
    
    @IBOutlet weak var dailyCalorieIntake: UILabel!
    @IBOutlet weak var cameraDes: UILabel!
    @IBOutlet weak var uploadDes: UILabel!
    @IBOutlet weak var typeDes: UILabel!
    @IBOutlet weak var foodPic: UIImageView!
    @IBOutlet weak var titleDes: UILabel!
    
    @IBAction func takePic(_ sender: Any) {
        if !UIImagePickerController.isSourceTypeAvailable(.camera) {
            return
        }
        
        let cameraPicker = UIImagePickerController()
        cameraPicker.delegate = self
        cameraPicker.sourceType = .camera
        cameraPicker.allowsEditing = false
        
        present(cameraPicker, animated: true)
        


    }
    
    @IBAction func upload(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.allowsEditing = false
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
        
    }
    
    @IBAction func typeAdd(_ sender: Any) {
        

    }
    
    //SELECT PHOTO FROM GALLERY
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true)
        
        guard let image = info["UIImagePickerControllerOriginalImage"] as? UIImage else {
            return
        }
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 299, height: 299), true, 2.0)
        image.draw(in: CGRect(x: 0, y: 0, width: 299, height: 299))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer : CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(newImage.size.width), Int(newImage.size.height), kCVPixelFormatType_32ARGB, attrs, &pixelBuffer)
        guard (status == kCVReturnSuccess) else {
            return
        }
  
        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)
        
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData, width: Int(newImage.size.width), height: Int(newImage.size.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) //3
        
        context?.translateBy(x: 0, y: newImage.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context!)
        newImage.draw(in: CGRect(x: 0, y: 0, width: newImage.size.width, height: newImage.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        
        
        
        cameraDes.isHidden = true
        uploadDes.isHidden = true
        typeDes.isHidden = true
        titleDes.isHidden = true
        
        addButton.isHidden = false
        foodPic.isHidden = false
        foodPic.image = newImage
        
        //SAVE IMAGE
        let uploadImage = newImage
        let uploadImageData:NSData = UIImagePNGRepresentation(uploadImage)! as NSData
        
        UserDefaults.standard.set(uploadImageData, forKey: "foodImage")

    }
        
        
    
    
    @IBAction func cancel(_ sender: Any) {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        dailyCalorieIntake.text = String(format: "%.2f", recommendedCalories)
        
        // Do any additional setup after loading the view.
    }
    
    //=============Variable for URL
    var urlsave: URL?
    @IBOutlet var imageViewer: UIImageView!
    
    
    
    @IBOutlet weak var addButton: UIButton!
    @IBAction func addButtonOutlet(_ sender: Any) {
        
        let ref = Database.database().reference()
        let stor = Storage.storage().reference()
        let tempImgRef = stor.child("tmpDir/tmpImage.jpg")
        //let image = UserDefaults.standard.object(forKey: "foodImage")//********************* <---- this is image
        let image = UIImage(data: (UserDefaults.standard.object(forKey: "foodImage") as! NSData) as Data)
        
        let metaData = StorageMetadata()
        metaData.contentType = "image/jpeg"
        
        tempImgRef.putData(UIImageJPEGRepresentation(image!, 0.8)!, metadata: metaData) { (data, error) in
            if error == nil {
                print("upload successful")
            } else {
                print(error?.localizedDescription)
            }
            print(metaData)
            print(metaData.downloadURLs)
        }

        sleep(1)
        
        //===============================Returns URL from FIREBASE
        
        //let stor = Storage.storage().reference()
        //let tempImgRef = stor.child("tmpDir/tmpImage.jpg")
        tempImgRef.getData(maxSize: 1 * 1000 * 1000) { (data, error) in
            if error == nil {
                print(data)
                self.imageViewer.image = UIImage(data: data!)
                
            } else{
                print(error?.localizedDescription)
            }
        }
        
        // Fetch the download URL
        tempImgRef.downloadURL { url, error in
            if let error = error {
                // Handle any errors
            } else {
                self.urlsave = url
                print(url)
                // Get the download URL for 'images/stars.jpg'
            }
        }
        
        sleep(1)
        
        
        //============================POST REQUEST TO STDLIB SERVER
        guard let urlString = urlsave?.absoluteString else { return }
        let service = MoyaProvider<StdLibService>()
        service.request(.uploadUrl(url: urlString)) { result in
            switch result {
            case let .success(moyaResponse):
                let data = moyaResponse.data
                
                let jsonSwift = try! JSON(data: data) //convert network data to json
                print(jsonSwift)
                
                //let response = try! JSONDecoder().decode([String].self, from: data)
                //let jsonString = try! JSONSerialization.jsonObject(with: data, options:[])
                //print(jsonString)
                
                //var str:String = response[0]
                //self.resultResponse.text = str
                
            case let .failure(_):
                break
            }
        }
    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    

}

extension ViewController: UIImagePickerControllerDelegate {
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}
