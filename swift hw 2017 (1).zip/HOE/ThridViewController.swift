//
//  ThridViewController.swift
//  HOEUITests
//
//  Created by Merlin Zhao on 11/18/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit


//String outputs
var profilePromptString = "TAP EDIT"
//hidden strings
var hidGenderString = "0"
var hidAgeString = "0"
var hidWeightString = "0"
var hidHeightString = "0"
var hidActivityString = "0"
var isNotHidden = 0

var recommendedCalories = 0.0
//User info numbers
var ageInt = 0.0
var weightInt = 0.0
var heightInt = 0.0
var activityInt = 0.0


class ThridViewController: UIViewController {

    //Hidden labels
    @IBOutlet weak var yourInfo: UILabel!
    @IBOutlet weak var hidGender: UILabel!
    @IBOutlet weak var hidAge: UILabel!
    @IBOutlet weak var hidWeight: UILabel!
    @IBOutlet weak var hidHeight: UILabel!
    @IBOutlet weak var hidActivity: UILabel!
    //Calorie output
    @IBOutlet weak var calorieDisplay: UILabel!
    @IBOutlet weak var calorieTitle: UILabel!
    //end hidden labels
    
    @IBOutlet weak var profilePic: UIImageView!
    
    @IBOutlet weak var welcomeBack: UILabel!
    @IBOutlet weak var profilePrompt: UILabel!
  
    @IBAction func editProfile(_ sender: Any) {
       
    }
    
    @IBAction func toOverview(_ sender: Any) {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    //BLURRED BACKGROUND
    @IBOutlet weak var blurr: UIVisualEffectView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //profile prompt
        profilePrompt.text = profilePromptString
        
        if isNotHidden == 1{
        
           
            
            //unhide things
            
            blurr.isHidden = false
            //blurr corners
            blurr.layer.cornerRadius = 35
            blurr.clipsToBounds = true
            
            //set values
            hidGender.text = hidGenderString
            hidAge.text = hidAgeString + " years old"
            hidHeight.text = hidHeightString + " cm"
            hidWeight.text = hidWeightString + " kg"
            hidActivity.text = "I exercise "+hidActivityString + " day(s) per week"
            
            //round calories
            
            calorieDisplay.text = String(format: "%.2f",recommendedCalories)
            
            yourInfo.isHidden = false
            hidGender.isHidden = false
            hidAge.isHidden = false
            hidWeight.isHidden = false
            hidHeight.isHidden = false
            hidActivity.isHidden =  false
            calorieTitle.isHidden = false
            calorieDisplay.isHidden = false
            
            
            
            
        }
        
        //load image
        let picData = UserDefaults.standard.object(forKey: "savedImage")
        profilePic.image = UIImage(data: picData as! Data)
        
        
        //round profile pic
        profilePic.layer.borderWidth = 1
        profilePic.layer.masksToBounds = false
        profilePic.layer.borderColor = UIColor.black.cgColor
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

