//
//  ViewController.swift
//  HOE
//
//  Created by Merlin Zhao on 11/17/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit

var totalCalToday = 0.0
var recommended = "Recommended: "

class ViewController: UIViewController {
    
    @IBOutlet weak var today: UILabel!

    @IBAction func addItem(_ sender: Any) {
        performSegue(withIdentifier: "toAddItem", sender: self)
    }

    @IBAction func moreDetails(_ sender: Any) {
        
        
    }
    
    
    @IBOutlet weak var totalCalDisplay: UILabel!
    @IBOutlet weak var recommendedCalToday: UILabel!
    
    @IBAction func toProfile(_ sender: Any) {
        performSegue(withIdentifier: "toProfileView", sender: self)
    }
    
  
    @IBAction func reload(_ sender: Any) {
        self.viewDidLoad()    }
    
    
   
    
    
    
    
    //============================================
    override func viewDidLoad() {
        super.viewDidLoad()
     
        
        //update total calories
        totalCalDisplay.text = String(format: "%.2f",totalCalToday)
        
        recommendedCalToday.text = recommended + String(format: "%.2f", recommendedCalories)
        
        let dateFormatter = DateFormatter()
        let date = Date()
        
        // US English Locale (en_US)
        dateFormatter.locale = Locale(identifier: "en_US")
        dateFormatter.setLocalizedDateFormatFromTemplate("MMMMd") // set template after setting locale
        today.text = dateFormatter.string(from: date) // December 31
        today.text = today.text?.uppercased() 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

