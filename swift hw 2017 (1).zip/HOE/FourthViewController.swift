//
//  FourthViewController.swift
//  HOE
//
//  Created by Merlin Zhao on 11/18/17.
//  Copyright © 2017 Merlin Zhao. All rights reserved.
//

import UIKit
import AVKit



class FourthViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UIImagePickerControllerDelegate,AVCaptureVideoDataOutputSampleBufferDelegate,UINavigationControllerDelegate {
    //profile pic
    @IBOutlet weak var profilePic: UIImageView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        pickerView.delegate = self
        pickerView.dataSource = self
        
        genderText.inputView = pickerView
        genderText.textAlignment = .center
       
        
        //set profile pic to default
        profilePic.layer.borderWidth = 1
        profilePic.layer.masksToBounds = false
        profilePic.layer.borderColor = UIColor.black.cgColor
        profilePic.layer.cornerRadius = profilePic.frame.height/2
        profilePic.clipsToBounds = true
        
    }
    @IBOutlet weak var ageText: UITextField!
    @IBOutlet weak var genderText: UITextField!
    @IBOutlet weak var nameText: UITextField!
    @IBOutlet weak var weightText: UITextField!
    @IBOutlet weak var heightText: UITextField!
    @IBOutlet weak var activityText: UITextField!
    
    //action for cancel button
    @IBAction func editCancel(_ sender: Any) {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }
    
    

    
    //save to variables
    @IBAction func saveEdit(_ sender: Any) {
     

        profilePromptString = nameText.text!
        hidGenderString = genderText.text!
        hidAgeString = ageText.text!
        hidWeightString = weightText.text!
        hidHeightString = heightText.text!
        hidActivityString = activityText.text!
        isNotHidden = 1
        
        ageInt = Double(ageText.text!)!
        weightInt = Double(weightText.text!)!
        heightInt = Double(heightText.text!)!
        
        
        //set acitivty multiplier, dpeends how often you work out
        if activityText.text! == "0"{
            activityInt = 1.2
        }
        else if activityText.text! == "1" || activityText.text! == "2" || activityText.text! == "3" {
            activityInt = 1.375
        }
        else if activityText.text! == "4" || activityText.text! == "5"{
            activityInt = 1.55
        }
        else if activityText.text! == "6" || activityText.text! == "7"{
            activityInt = 1.9
        }
        
        if hidGenderString == "Male"{
            recommendedCalories = activityInt*(66.473 + (13.7516 * weightInt) + (5.0033 * heightInt - (6.7550 * ageInt)))
        }
        else if hidGenderString == "Female"{
            recommendedCalories = activityInt*(655.0955 + 9.5634*weightInt + 1.8496*heightInt - 4.6756*ageInt)
        }
        
       
        
      
       // performSegue(withIdentifier: "finishEdit", sender: self)
        presentingViewController?.dismiss(animated: true, completion: nil)

       
    }
    
    //Upload profile image
   
    @IBOutlet weak var profileImageView: UIImageView!
    @IBAction func uploadProfile(_ sender: Any) {
        let picker = UIImagePickerController()
        picker.allowsEditing = false
        picker.delegate = self
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        picker.dismiss(animated: true)
        
        guard let image = info["UIImagePickerControllerOriginalImage"] as? UIImage else {
            return
        }
        
        UIGraphicsBeginImageContextWithOptions(CGSize(width: 299, height: 299), true, 2.0)
        image.draw(in: CGRect(x: 0, y: 0, width: 299, height: 299))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        
        let attrs = [kCVPixelBufferCGImageCompatibilityKey: kCFBooleanTrue, kCVPixelBufferCGBitmapContextCompatibilityKey: kCFBooleanTrue] as CFDictionary
        var pixelBuffer : CVPixelBuffer?
        let status = CVPixelBufferCreate(kCFAllocatorDefault, Int(newImage.size.width), Int(newImage.size.height), kCVPixelFormatType_32ARGB, attrs, &pixelBuffer)
        guard (status == kCVReturnSuccess) else {
            return
        }
        
        CVPixelBufferLockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        let pixelData = CVPixelBufferGetBaseAddress(pixelBuffer!)
        
        let rgbColorSpace = CGColorSpaceCreateDeviceRGB()
        let context = CGContext(data: pixelData, width: Int(newImage.size.width), height: Int(newImage.size.height), bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixelBuffer!), space: rgbColorSpace, bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) //3
        
        context?.translateBy(x: 0, y: newImage.size.height)
        context?.scaleBy(x: 1.0, y: -1.0)
        
        UIGraphicsPushContext(context!)
        newImage.draw(in: CGRect(x: 0, y: 0, width: newImage.size.width, height: newImage.size.height))
        UIGraphicsPopContext()
        CVPixelBufferUnlockBaseAddress(pixelBuffer!, CVPixelBufferLockFlags(rawValue: 0))
        
        
        
        profileImageView.image = newImage
        
        //SAVE IMAGE
        let imageProfile = newImage
        let imageProfileData:NSData = UIImagePNGRepresentation(imageProfile)! as NSData

        UserDefaults.standard.set(imageProfileData, forKey: "savedImage")
        
        
    }
    
    
    //list for ender picker
    let gender = ["Select Gender", "Male","Female"]
    var pickerView = UIPickerView()
    

    // returns the number of 'columns' to display.
    public func numberOfComponents(in pickerView: UIPickerView) -> Int{
        return 1;
    }
    // returns the # of rows in each component..
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int{
        return gender.count
    }
    internal func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return String(gender[row])
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        genderText.text = String(gender[row])
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}


