//
//  StdLibService.swift
//  firebase101
//
//  Created by Sunny Siu on 2017-11-18.
//  Copyright © 2017 Sunny Siu. All rights reserved.
//

import Foundation
import Moya

enum StdLibService {
    case uploadUrl(url : String)
}

extension StdLibService: TargetType {
    var baseURL: URL {
        return URL(string: "https://matthewchan.stdlib.com")!
    }
    
    var path: String {//same as switch
        return "/hw@dev/"
    }
    
    var method: Moya.Method {
        return .post
    }
    
    var sampleData: Data {//keep returning
        return "".utf8Encoded
    }
    
    var task: Task {
        switch self {
        case .uploadUrl(let url):
            let parameters = ["URL": url]
            return .requestParameters(parameters: parameters, encoding: JSONEncoding.default)
        }
    }
    
    var headers: [String : String]? {
        return nil
    }
    
    
}

// MARK: - Helpers
private extension String {
    var urlEscaped: String {
        return addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!
    }
    
    var utf8Encoded: Data {
        return data(using: .utf8)!
    }
}
